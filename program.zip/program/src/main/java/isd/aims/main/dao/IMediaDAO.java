package isd.aims.main.dao;

public interface IMediaDAO {
}
