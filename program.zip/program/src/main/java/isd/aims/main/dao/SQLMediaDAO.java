package isd.aims.main.dao;

public class SQLMediaDAO {
}
